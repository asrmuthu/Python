n=int(input())
if (n % 2) == 0:
    print("odd number")
else:
    print("even number")
