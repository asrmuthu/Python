##a,b,c=input("enter three names : ").split(',')
a,b,c="muthu,pandi,raj".split(',')
print(a,b,c)
d="muthu"
print(type(a))
para=["muthu","p","andi"]
print(' | '.join(para))

#output
'''muthu pandi raj
<class 'str'>
muthu | p | andi'''

