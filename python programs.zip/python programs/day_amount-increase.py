day = input("select day \n")
if(day=="friday" or day=="saturday" or day=="sunday") :
    print("\n 10% increase "+day)
else :
    print("\n o% increase "+day)
