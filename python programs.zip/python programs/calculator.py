##x=int(input("enter the number x \n"))
##y=int(input("enter the number y \n"))
##a=x+y
##b=x-y
##c=x*y
##d=x//y
##print(a,b,c,d)

print(eval(input("enter the numbers \n")))
  
