actual=1234
b = int(input("enter upi pin"))
while actual!=b :
     print("retry payment")
     b=int(input("enter upi pin"))
print("Payment Sucesss")
