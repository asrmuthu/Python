import math

print(math.sqrt(4))
print(math.ceil(4.6586))
print(math.floor(4.6586))
print(math.factorial(5))
print(math.fabs(-5)) #native number convert to pasitive number
print(math.pow(2,3))
print(math.log2(8))
print(math.pi)
print(math.e)