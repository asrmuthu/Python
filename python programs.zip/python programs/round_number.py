import math

x=18
y=5
s=5
u=3
a=x/y
b=x/y
c=x/y # it also same, x // y
d=x/y
e=s/u

# normal 
print("normal",a)

# greatest number ceil
print("ceil - greatest number", math.ceil(b))

# smallest number floor
print("floor - smallest", math.floor(c))

# correct value - round
print("round - correct value ", round(d))

# smallest number trunc
print("trunc - ", math.trunc(e))
