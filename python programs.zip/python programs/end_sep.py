#end
a =input()
print(a, end=' good \n')
#sep
print("Study", "tonight", "sweet", "dreams", sep = '$ ')

#end each latter or words
for i in "python":
  print(i, end=":")
