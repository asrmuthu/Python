#It like array. single variable ---> can store multiple values in list 
#list can contains string and integers, Allow duplicates, changeable

a = ["muthu","pandi","1","2","4"]
print(a[0])    #answer - muthu
print(a[-1])   #answer - 4
print(len(a))   #answer - 5
print(a)        #answer - ["muthu","pandi","1","2","4"]
List = [['Geeks', 'For'], ['Geeks']]
print(List[0])   #answer - ['Geeks']
print(a[1:3])    #answer - ["pandi","1"]
print(a[2:])    #answer - ["1","2","4"]
print(a[:2])    #answer - ["muthu","pandi"]
print(a[1:-1])    #answer - ["pandi","1","2"]
a[3]="raj"    #change - answer - ["muthu","pandi","1","raj","4"]
print(a) 
a.insert(4,"do") #insert- answer -['muthu', 'pandi', '1', 'raj', 'do', '4']
print(a) 
a.append("last") #append-only last- answer -['muthu', 'pandi', '1', 'raj', 'do', '4', 'last']
print(a)
a.remove("pandi") #remove-delete only for values -['muthu', '1', 'raj', 'do', '4', 'last']
print(a)
a.pop(5) #pop- delete index value -['muthu', '1', 'raj', 'do', '4']
print(a)
del a[3]
print(a)  #delete parmently in memory ['muthu', '1', 'raj', '4']
#del a -  list fully permantly deleted
#a.clear() #empty the list, not permantly deleted -answer - []
#print(a)

b= input()
a.append(b)  #insert user input last- answer- ['muthu', '1', 'raj', '4', 'manual']
print(a)
c= input()
a.insert(2,c)  #insert user input particular place- answer- ['muthu', '1', 'raj', '4', 'manual']
print(a)

#new list
mp = [1,2,3,4]
x=len(mp)
print(x) # length of list
ms=[4,5,6]
m=mp+ms
print(m) # two list merge
y=mp * 5  # n number of list
print(y)
#nested list is list kula list
nes =[[1,2],[2,3],[4,5]]
print(nes[2]) # list kula irukura list specy pannalam
print(nes[2][0]) # nested list kula irukura value edukurathu
for i in nes:
    print(i)
n_list = [5,2,1,2,3,2,4,3]
print(list(dict.fromkeys(n_list))) # remove dublicate list
print(set(n_list)) # remove dublicate and orederd 






    

