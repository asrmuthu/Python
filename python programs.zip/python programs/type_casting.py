#type casting -> oru datatype la irunthu ennoru data type ah mathurathu

a=55.6
b=int(a)
print(b)
print(type(b))
