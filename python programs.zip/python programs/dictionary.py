d={'a':1,'b':2,'c':3}
print(d)
person1_information = {}

# add the key, value information with key “city”
person1_information["city"] = "San Francisco"
print(person1_information)

# add another key, value information with key “name”
person1_information["name"] = "Sam"
print(person1_information)

# add another key, value information with key “food”
person1_information["food"] = "shrimps"
print(person1_information)

remaining_information = {'name': 'muthu', "food": "ice"}
# add the second dictionary remaining_information to personal1_information using the update method
person1_information.update(remaining_information)
print(person1_information)
del person1_information["food"]
print(person1_information)