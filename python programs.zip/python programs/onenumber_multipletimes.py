a=input("enter the number: ")
print(a*5)