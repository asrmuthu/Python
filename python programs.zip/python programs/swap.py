a = int( input("Please enter value for a: "))  
b = int( input("Please enter value for b: "))  
   
# To swap the value of two variables  
# we will user third variable which is a temporary variable  
c = a 
a = b 
b = c  
   
print ("The Value of a after swapping: ", a)  
print ("The Value of b after swapping: ", b)
print ("The Value of c after swapping: ", c) 
