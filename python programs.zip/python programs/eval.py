
print(eval("5+9-5*2/2"))
print(eval("2**3"))
print(eval("max(10,6,8,7,6)"))

