s="sample"
print(s[0:2])
print(s[2:])
print(s[::-1]) #reverse the letter
