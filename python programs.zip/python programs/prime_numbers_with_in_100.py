i=5

while i>3 and i<10:
          print(i)
          i+=1
