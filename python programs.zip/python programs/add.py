a=5
b=10
c=a+b
print(c)
