def wel():
    print("we to all")
    print("thank you")
    print("so much")
wel()
wel()
wel()
