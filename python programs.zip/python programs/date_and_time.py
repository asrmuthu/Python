import datetime

##a = datetime.datetime(2050,6,5)
a = datetime.datetime.now()
print(a.strftime("%A"))
print(a.strftime("%B"))
print(a.strftime("%C"))
print(a.strftime("%D"))
print(a.strftime("%F"))
print(a.strftime("%G"))
