a=["first","second","3","four",'5']
print(a)
a.pop(2)
print(a)
a[3]="third"
print(a)
a.clear()
print(a)
del a





