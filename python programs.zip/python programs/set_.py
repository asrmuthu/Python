#seperate each every one
setA = set("HackerEarth")
print(setA)
setB = set(["C", "C++", "Python"])
print(setB)
setC = set([1, 2, 3, 4, 5, 6, 7, 7, 7])
print(setC)