a=int(input("enter the number "))
for i in range(1,a+1):
    print(a)
