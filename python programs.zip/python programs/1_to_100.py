a =int(input("enter the number \n"))
for i in range(1, a+1):
  print(i)  #output - 1,2,3.....

--- 
i =1
while i<=10:
print(i)
i+=1
---
